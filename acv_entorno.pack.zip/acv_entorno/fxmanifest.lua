fx_version "cerulean"
game "gta5"
use_fxv2_oal 'yes'
lua54 'yes'

owner 'print("HolaMundo")'
description 'Este recurso es para esx y solo funcionara con el gksphone'
version '1.1.0'

client_script "main.lua"


dependency '/assetpacks'