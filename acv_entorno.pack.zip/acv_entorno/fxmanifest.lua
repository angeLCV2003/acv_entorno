fx_version "cerulean"
game "gta5"

owner 'print("HolaMundo")'
description 'Este recurso es para esx y solo funcionara con el gksphone'

version '1.1.0'
lua54 'yes'


client_script "main.lua"


dependency '/assetpacks'