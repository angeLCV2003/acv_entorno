fx_version "cerulean"
game "gta5"

author 'ACV'
version '1.0.0'
client_script "main.lua"
lua54 'yes'


dependency '/assetpacks'