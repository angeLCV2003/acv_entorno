fx_version "cerulean"
game "gta5"

author 'print("HolaMundo")'
description 'Este recurso es para esx y solo funcionara con el gksphone'

version '1.2.0'
lua54 'yes'


client_script "main.lua"


dependency '/assetpacks'